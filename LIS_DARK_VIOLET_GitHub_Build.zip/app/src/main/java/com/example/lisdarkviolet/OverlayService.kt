package com.example.lisdarkviolet

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val purple = Color.rgb(180, 90, 255)
    private val dark = Color.rgb(18, 13, 29)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) showBubble()
        return START_NOT_STICKY
    }

    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "DV"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(dark)
                setStroke(3, purple)
            }
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        wm.addView(bubble, params(58, 58))
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = GradientDrawable().apply {
                setColor(dark)
                cornerRadius = 22f
                setStroke(3, purple)
            }
        }
        val heading = TextView(this).apply {
            text = "LIS DARK VIOLET"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple)
            setPadding(0, 0, 0, 10)
        }
        box.addView(heading)
        listOf("ESP — демо-переключатель", "Aimbot — демо-переключатель",
            "No Aggro — демо-переключатель", "No Turret — демо-переключатель",
            "Защита от техники — демо", "RT Unlock — демо").forEach { label ->
            var enabled = false
            val row = TextView(this).apply {
                text = "○  $label"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(4, 9, 4, 9)
                setOnClickListener {
                    enabled = !enabled
                    text = (if (enabled) "●  " else "○  ") + label
                    setTextColor(if (enabled) purple else Color.WHITE)
                }
            }
            box.addView(row)
        }
        val close = TextView(this).apply {
            text = "Скрыть меню"
            gravity = Gravity.CENTER
            setTextColor(purple)
            setPadding(0, 12, 0, 2)
            setOnClickListener { hidePanel() }
        }
        box.addView(close)
        panel = box
        wm.addView(panel, params(300, WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun hidePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }
}
